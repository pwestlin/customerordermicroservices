package nu.westlin.microservices.orderservice

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class OrderServiceApplicationTests {

	@Test
	fun contextLoads() {
	}

}
